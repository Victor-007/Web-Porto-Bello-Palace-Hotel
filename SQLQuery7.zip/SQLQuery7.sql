use hotellll
drop cadastro
drop login
create table login(
id_login integer primary key,
email varchar(50),
senha varchar(50),
nova_senha varchar(50),
);

create table cadastro(
id_cad integer,
nome varchar(50),
email varchar (50),
telefone varchar (50),
cpf int,
rg int,
sexo varchar (50),
data_nasc date,
cidade varchar (50),
estado varchar (50),

CONSTRAINT fk_id FOREIGN KEY (id_cad) REFERENCES login (id_login)
)

CONSTRAINT fk_ped FOREIGN KEY (cpf) REFERENCES cadastro (cpf)

CONSTRAINT fk_prod FOREIGN KEY (id_produto) REFERENCES produto1 (id)

create table pedido1 (
id_pedido integer primary key,
pedido varchar (50),
data date,
cpf_ped int,
id_produto int,

CONSTRAINT fk_ped FOREIGN KEY (cpf_ped) REFERENCES cadastro (cpf),
CONSTRAINT fk_prod FOREIGN KEY (id_produto) REFERENCES produto1 (id),
);

alter table cadastro alter column cpf int not null
alter table cadastro add primary key (cpf)


create table produto1 (
id integer primary key,
produto varchar (50),
preco money,
datacompra date,
);

create table reserva (
id_reserva integer primary key,
data_checkin date,
data_checkout date,
adulto int,
criancas int,
quartos varchar (50),
tipos_quarto varchar (50),
valor money,
cpf int,
id_pedido integer,

CONSTRAINT fk_resped FOREIGN KEY (id_pedido) REFERENCES pedido1 (id_pedido),
CONSTRAINT fk_rescad FOREIGN KEY (cpf) REFERENCES cadastro (cpf),

);